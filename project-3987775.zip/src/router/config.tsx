import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import Accessories from "../pages/accessories/page";
import Brands from "../pages/brands/page";
import Support from "../pages/support/page";
import Contact from "../pages/contact/page";
import SignIn from "../pages/auth/signin/page";
import SignUp from "../pages/auth/signup/page";
import Wishlist from "../pages/wishlist/page";
import BrandDetail from "../pages/brand/page";
import ProductDetail from "../pages/product/page";
import AdminLogin from '../pages/auth/admin-login/page';
import AdminDashboard from '../pages/admin/dashboard/page';

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/accessories",
    element: <Accessories />,
  },
  {
    path: "/brands",
    element: <Brands />,
  },
  {
    path: "/brand/:brandName",
    element: <BrandDetail />,
  },
  {
    path: "/product/:id",
    element: <ProductDetail />,
  },
  {
    path: "/support",
    element: <Support />,
  },
  {
    path: "/contact",
    element: <Contact />,
  },
  {
    path: "/signin",
    element: <SignIn />,
  },
  {
    path: "/signup",
    element: <SignUp />,
  },
  {
    path: "/wishlist",
    element: <Wishlist />,
  },
  {
    path: "/auth/signin",
    element: <SignIn />
  },
  {
    path: "/auth/signup",
    element: <SignUp />
  },
  {
    path: "/auth/admin",
    element: <AdminLogin />
  },
  {
    path: '/admin/dashboard',
    element: <AdminDashboard />
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
