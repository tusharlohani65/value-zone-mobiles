
import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Header from '../../../components/feature/Header';
import Footer from '../../../components/feature/Footer';
import Button from '../../../components/base/Button';
import Card from '../../../components/base/Card';

export default function SignUp() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreeToTerms: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match!');
      return;
    }
    
    if (!formData.agreeToTerms) {
      setError('Please agree to the Terms of Service and Privacy Policy');
      return;
    }

    setIsLoading(true);
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Store user session
      localStorage.setItem('user', JSON.stringify({
        email: formData.email,
        name: formData.name,
        loginMethod: 'email',
        isLoggedIn: true
      }));
      
      // Redirect to home
      navigate('/');
    } catch (err) {
      setError('Registration failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    setError('');
  };

  const handleGoogleSignUp = async () => {
    setSocialLoading('google');
    setError('');
    
    try {
      // Simulate Google OAuth flow
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Store user session with Google data
      localStorage.setItem('user', JSON.stringify({
        email: 'newuser@gmail.com',
        name: 'Google User',
        loginMethod: 'google',
        isLoggedIn: true,
        avatar: 'https://readdy.ai/api/search-image?query=professional%20user%20avatar%20profile%20picture%20modern%20clean%20business%20person&width=100&height=100&seq=googlesignup1&orientation=squarish'
      }));
      
      // Redirect to home
      navigate('/');
    } catch (err) {
      setError('Google sign-up failed. Please try again.');
    } finally {
      setSocialLoading('');
    }
  };

  const handleFacebookSignUp = async () => {
    setSocialLoading('facebook');
    setError('');
    
    try {
      // Simulate Facebook OAuth flow
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Store user session with Facebook data
      localStorage.setItem('user', JSON.stringify({
        email: 'newuser@facebook.com',
        name: 'Facebook User',
        loginMethod: 'facebook',
        isLoggedIn: true,
        avatar: 'https://readdy.ai/api/search-image?query=professional%20user%20avatar%20profile%20picture%20modern%20clean%20business%20person&width=100&height=100&seq=facebooksignup1&orientation=squarish'
      }));
      
      // Redirect to home
      navigate('/');
    } catch (err) {
      setError('Facebook sign-up failed. Please try again.');
    } finally {
      setSocialLoading('');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <main className="flex-1 py-12">
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Account</h1>
            <p className="text-gray-600">Join us and start shopping today</p>
          </div>

          <Card className="p-8">
            {error && (
              <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-semibold text-gray-900 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  disabled={isLoading || socialLoading !== ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm disabled:bg-gray-100"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-gray-900 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  disabled={isLoading || socialLoading !== ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm disabled:bg-gray-100"
                  placeholder="your.email@example.com"
                />
              </div>

              <div>
                <label htmlFor="password" className="block text-sm font-semibold text-gray-900 mb-2">
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  minLength={8}
                  disabled={isLoading || socialLoading !== ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm disabled:bg-gray-100"
                  placeholder="Create a strong password"
                />
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-semibold text-gray-900 mb-2">
                  Confirm Password
                </label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  minLength={8}
                  disabled={isLoading || socialLoading !== ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent text-sm disabled:bg-gray-100"
                  placeholder="Re-enter your password"
                />
              </div>

              <div className="flex items-start">
                <input
                  type="checkbox"
                  id="agreeToTerms"
                  name="agreeToTerms"
                  checked={formData.agreeToTerms}
                  onChange={handleChange}
                  required
                  disabled={isLoading || socialLoading !== ''}
                  className="w-4 h-4 mt-1 text-orange-600 cursor-pointer disabled:cursor-not-allowed"
                />
                <label htmlFor="agreeToTerms" className="ml-2 text-sm text-gray-700 cursor-pointer">
                  I agree to the{' '}
                  <a href="#" className="text-orange-600 hover:text-orange-700 font-semibold">
                    Terms of Service
                  </a>{' '}
                  and{' '}
                  <a href="#" className="text-orange-600 hover:text-orange-700 font-semibold">
                    Privacy Policy
                  </a>
                </label>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 whitespace-nowrap"
                disabled={isLoading || socialLoading !== ''}
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <i className="ri-loader-4-line animate-spin mr-2"></i>
                    Creating Account...
                  </div>
                ) : (
                  'Create Account'
                )}
              </Button>
            </form>

            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">Or sign up with</span>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-2 gap-3">
                <button 
                  onClick={handleGoogleSignUp}
                  disabled={isLoading || socialLoading !== ''}
                  className="flex items-center justify-center px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {socialLoading === 'google' ? (
                    <i className="ri-loader-4-line animate-spin text-gray-400"></i>
                  ) : (
                    <>
                      <i className="ri-google-fill text-xl text-red-500 mr-2"></i>
                      <span className="text-sm font-medium text-gray-700">Google</span>
                    </>
                  )}
                </button>
                <button 
                  onClick={handleFacebookSignUp}
                  disabled={isLoading || socialLoading !== ''}
                  className="flex items-center justify-center px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {socialLoading === 'facebook' ? (
                    <i className="ri-loader-4-line animate-spin text-gray-400"></i>
                  ) : (
                    <>
                      <i className="ri-facebook-fill text-xl text-blue-600 mr-2"></i>
                      <span className="text-sm font-medium text-gray-700">Facebook</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <p className="mt-6 text-center text-sm text-gray-600">
              Already have an account?{' '}
              <Link to="/signin" className="text-orange-600 hover:text-orange-700 font-semibold cursor-pointer">
                Sign in
              </Link>
            </p>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  );
}
