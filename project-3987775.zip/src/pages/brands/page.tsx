import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import BrandsGrid from './components/BrandsGrid';

export default function Brands() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Top Mobile Brands</h1>
            <p className="text-xl text-indigo-100 max-w-2xl">
              Explore premium smartphones from the world's leading technology brands
            </p>
          </div>
        </section>

        <BrandsGrid />
      </main>
      <Footer />
    </div>
  );
}
