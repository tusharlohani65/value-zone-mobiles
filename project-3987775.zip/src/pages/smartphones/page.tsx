import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import ProductList from './components/ProductList';
import FilterSidebar from './components/FilterSidebar';
import { useState } from 'react';

export default function Smartphones() {
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [priceRange, setPriceRange] = useState<string>('all');

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Premium Smartphones</h1>
            <p className="text-xl text-blue-100 max-w-2xl">
              Discover the latest flagship smartphones with cutting-edge technology, powerful performance, and stunning cameras
            </p>
          </div>
        </section>

        {/* Products Section */}
        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col lg:flex-row gap-8">
              <FilterSidebar 
                selectedBrand={selectedBrand}
                setSelectedBrand={setSelectedBrand}
                priceRange={priceRange}
                setPriceRange={setPriceRange}
              />
              <ProductList 
                selectedBrand={selectedBrand}
                priceRange={priceRange}
              />
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
