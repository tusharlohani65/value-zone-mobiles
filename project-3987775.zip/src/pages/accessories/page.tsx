
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import AccessoriesGrid from './components/AccessoriesGrid';

export default function Accessories() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Premium Tech Accessories & Gadgets</h1>
            <p className="text-xl text-purple-100 max-w-3xl">
              Discover the latest smartwatches from Noise & boAt, premium audio from JBL, fast chargers from Portronics, ring lights, gimbals, GoPro accessories, CCTV cameras, and more
            </p>
          </div>
        </section>

        <AccessoriesGrid />
      </main>
      <Footer />
    </div>
  );
}
