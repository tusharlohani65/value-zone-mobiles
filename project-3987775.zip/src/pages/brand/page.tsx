
import { useParams } from 'react-router-dom';
import Header from '../../components/feature/Header';
import Footer from '../../components/feature/Footer';
import BrandProducts from './components/BrandProducts';

export default function BrandDetail() {
  const { brandName } = useParams<{ brandName: string }>();

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <BrandProducts brandName={brandName || ''} />
      </main>
      <Footer />
    </div>
  );
}